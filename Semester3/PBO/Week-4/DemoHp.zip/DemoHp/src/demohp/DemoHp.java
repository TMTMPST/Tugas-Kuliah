/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demohp;

/**
 *
 * @author vidoe
 */
public class DemoHp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic herepublic static void main(String[] args) {
        // Membuat objek HandPhone
        HandPhone hp = new HandPhone("123456", "ModelX", "Android 12");
        
        
        hp.info();  
        hp.power(); 
        hp.kurangVolume(); 
        hp.tambahVolume(); 
        
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.tambahVolume(); 
        hp.mute();  
        hp.mute();
       
        hp.tambahVolume();  
        hp.power();  
        hp.info();  
    }
}
    
